{{- define "shop.labels" -}}
app.kubernetes.io/part-of: storefront
app.kubernetes.io/instance: {{ .Release.Name }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}
